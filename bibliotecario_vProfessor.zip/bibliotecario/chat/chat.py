from flask import Flask, render_template, Response, request, session
import requests
import json

import secrets

URL_ROBO = "http://localhost:5000"
URL_ROBO_ALIVE = f"{URL_ROBO}/alive"
URL_ROBO_RESPONDER = f"{URL_ROBO}/responder"
URL_ROBO_PESQUISAR_ARTIGOS = f"{URL_ROBO}/artigos"

CONFIANCA_MINIMA = 0.60

chat = Flask(__name__)
chat.secret_key = secrets.token_hex(16)

def acessar_robo(url, para_enviar = None):
    sucesso, resposta = False, None    

    try:
        if para_enviar:
            resposta = requests.post(url, json=para_enviar)
        else:
            resposta = requests.get(url)
        
        resposta = resposta.json()

        sucesso = True
    except Exception as e:
        print(f"erro acessando back-end: {str(e)}")

    return sucesso, resposta

def robo_alive():
    sucesso, resposta = acessar_robo(URL_ROBO_ALIVE)

    return sucesso and resposta["alive"] == "sim"

def perguntar_robo(pergunta):
    sucesso, resposta = acessar_robo(URL_ROBO_RESPONDER, {"pergunta": pergunta})

    mensagem = "Infelizmente, ainda não sei responder esta pergunta. Entre em contato com a biblioteca. Mais informações no site https://portal.ifba.edu.br/conquista/ensino/biblioteca"
    if sucesso and resposta["confianca"] >= CONFIANCA_MINIMA:
            mensagem = resposta["resposta"]

    return mensagem

def pesquisar_artigos(chaves):
    ...
    
    return None

@chat.get("/")
def index():
    return render_template("index.html")

@chat.post("/responder")
def get_resposta():
    conteudo = request.json
    pergunta = conteudo["pergunta"]

    resposta = perguntar_robo(pergunta)

    return Response(json.dumps({"resposta": resposta}), status=200, mimetype="application/json")

if __name__ == "__main__":
    chat.run(
        host = "0.0.0.0",
        port = 5001,
        debug=True
    )
